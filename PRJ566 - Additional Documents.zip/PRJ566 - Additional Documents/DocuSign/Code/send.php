<?php

require_once('docusign-php-client/autoload.php');

function signatureRequestFromTemplate($email)
{
    $username = "kleverloza@gmail.com";
    $password = "PRJ566_group1";
    $integrator_key = "62d2e640-687a-4729-ac82-3d6ff8353ec9";     

    // change to production before going live
    $host = "https://demo.docusign.net/restapi";

    // create configuration object and configure custom auth header
    $config = new DocuSign\eSign\Configuration();
    $config->setHost($host);
    $config->setSSLVerification(false);
    $config->addDefaultHeader("X-DocuSign-Authentication", "{\"Username\":\"" . $username . "\",\"Password\":\"" . $password . "\",\"IntegratorKey\":\"" . $integrator_key . "\"}");

    // instantiate a new docusign api client
    $apiClient = new DocuSign\eSign\ApiClient($config);
    $accountId = null;

    try 
    {
        //*** STEP 1 - Login API
        $authenticationApi = new DocuSign\eSign\Api\AuthenticationApi($apiClient);
        $options = new \DocuSign\eSign\Api\AuthenticationApi\LoginOptions();
        $loginInformation = $authenticationApi->login($options);
        if(isset($loginInformation) && count($loginInformation) > 0)
        {
            $loginAccount = $loginInformation->getLoginAccounts()[0];
            if(isset($loginInformation))
            {
                $accountId = $loginAccount->getAccountId();
                if(!empty($accountId))
                {
                    //*** STEP 2 - Signature Request from a Template
                    // create envelope call is available in the EnvelopesApi
                    $envelopeApi = new DocuSign\eSign\Api\EnvelopesApi($apiClient);
                    // assign recipient to template role by setting name, email, and role name.  Note that the
                    // template role name must match the placeholder role name saved in your account template.
                    $templateRole = new  DocuSign\eSign\Model\TemplateRole();
                    $templateRole->setEmail($email);
                    $templateRole->setName("Klever Loza Vega");
                    $templateRole->setRoleName("[ROLE_NAME]");             

                    // instantiate a new envelope object and configure settings
                    $envelop_definition = new DocuSign\eSign\Model\EnvelopeDefinition();
                    $envelop_definition->setEmailSubject("[DocuSign PHP SDK] - Signature Request Sample");
                    $envelop_definition->setTemplateId("[TEMPLATE_ID]");
                    $envelop_definition->setTemplateRoles(array($templateRole));

                    // set envelope status to "sent" to immediately send the signature request
                    $envelop_definition->setStatus("sent");

                    // optional envelope parameters
                    $options = new \DocuSign\eSign\Api\EnvelopesApi\CreateEnvelopeOptions();
                    $options->setCdseMode(null);
                    $options->setMergeRolesOnDraft(null);

                    // create and send the envelope (aka signature request)
                    $envelop_summary = $envelopeApi->createEnvelope($accountId, $envelop_definition, $options);
                    if(!empty($envelop_summary))
                    {
                        echo "$envelop_summary";
                    }
                }
            }
        }
    }
    catch (DocuSign\eSign\ApiException $ex)
    {
        echo "Exception: " . $ex->getMessage() . "\n";
    }
}

if ($_POST) {
    if($_POST["email"] != ""){
        signatureRequestFromTemplate($_POST["email"]);
    }
} else {
?>

<!DOCTYPE html>
<html>
<head>
    <title>Send Template</title>
</head>
<body>
    <form method="POST" action="send.php">
        Email: <input type="text" name="email"><br /> 
        <input type="submit" value="Submit" name="action">
    </form>
</body>
</html>
<?php
}
?>